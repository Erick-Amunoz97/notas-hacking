
# Reto

## Descripcion

## Pistas

## Solucion

```bash()
```

## Bandera

picoCTF{}

## Notas adicionales

| comando | descripcion

## Referencias
